Implement Entitlement Middleware (Stripe-Ready, Provider-Agnostic)

SCOPE:
Only modify /services/iprocore-api
Do NOT refactor other services.
Do NOT modify deployment files.
Do NOT change existing auth logic.
Keep changes minimal and modular.

OBJECTIVE:
Implement a minimal, production-ready entitlement enforcement system that:
- Validates active subscription
- Validates feature entitlement
- Enforces usage limits
- Is provider-agnostic
- Is Stripe-ready (stub only, no Stripe SDK yet)

------------------------------------------
STEP 1 — DATABASE MODELS (Prisma update)
------------------------------------------

Add the following models to Prisma schema:

model Subscription {
  id                    String   @id @default(uuid())
  tenantId              String   @unique
  provider              String   // "STRIPE" | "MANUAL"
  providerSubscriptionId String?
  plan                  String
  status                String   // "ACTIVE" | "PAST_DUE" | "CANCELED" | "TRIAL"
  currentPeriodEnd      DateTime?
  createdAt             DateTime @default(now())
  updatedAt             DateTime @updatedAt
}

model Entitlement {
  id          String @id @default(uuid())
  plan        String
  featureKey  String
  limit       Int?   // null = unlimited
}

model UsageCounter {
  id         String  @id @default(uuid())
  tenantId   String
  featureKey String
  used       Int     @default(0)

  @@unique([tenantId, featureKey])
}

model StripeCustomer {
  id               String @id @default(uuid())
  tenantId         String @unique
  stripeCustomerId String
}

Do NOT modify other models.

------------------------------------------
STEP 2 — ENTITLEMENT SERVICE
------------------------------------------

Create file:

/services/iprocore-api/src/entitlements/entitlement.service.ts

Implement:

- getActiveSubscription(tenantId)
- getPlanEntitlements(plan)
- checkUsage(tenantId, featureKey)
- incrementUsage(tenantId, featureKey)
- requireEntitlement(featureKey: string)

requireEntitlement logic:

1. Get active subscription
2. If none or status != ACTIVE → throw 403
3. Fetch entitlement for plan + featureKey
4. If not found → throw 403
5. If limit exists:
      fetch UsageCounter
      if used >= limit → throw 403
6. Allow request

Do NOT call Stripe.
Do NOT introduce billing logic.

------------------------------------------
STEP 3 — MIDDLEWARE
------------------------------------------

Create:

/services/iprocore-api/src/middleware/requireEntitlement.ts

Export:

requireEntitlement(featureKey: string)

Middleware assumes:
req.user
req.activeTenantId

Return 403 if blocked.

------------------------------------------
STEP 4 — STRIPE STUB (NO SDK)
------------------------------------------

Create folder:

/services/iprocore-api/src/billing/stripe/

Add:

stripe.service.ts
stripe.webhook.ts

stripe.service.ts:
Export placeholder functions:
- createCustomer()
- createSubscription()

They only log and throw "Not implemented".

stripe.webhook.ts:
Export handler function:
- handleStripeWebhook()

No logic inside yet.

------------------------------------------
STEP 5 — ROUTE PLACEHOLDER
------------------------------------------

Add route:

POST /billing/stripe/webhook

It should:
- accept JSON
- log event
- return 200 OK

No validation needed yet.

------------------------------------------
STEP 6 — SEED DATA
------------------------------------------

Seed default plans:

Starter:
  featureKey: "portfolio.create"
  limit: 5

Pro:
  featureKey: "portfolio.create"
  limit: 50

Enterprise:
  featureKey: "portfolio.create"
  limit: null (unlimited)

------------------------------------------
CONSTRAINTS
------------------------------------------

- Do NOT integrate Stripe SDK.
- Do NOT modify authentication system.
- Do NOT modify tenancy system.
- Keep code modular.
- Do NOT exceed 300 lines per file.
- Do NOT introduce new architecture patterns.

END OF SKILL.