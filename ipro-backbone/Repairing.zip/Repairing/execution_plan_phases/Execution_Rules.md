# Antigravity Execution Rules (Non-Negotiable)

1. Never refactor entire services.
2. Only modify files explicitly requested.
3. Never rename existing folders unless instructed.
4. Keep changes under 300 lines per skill.
5. Do not introduce new architectural patterns.
6. Do not modify deployment files unless requested.
7. Never change existing API responses unless required.
8. Always preserve backward compatibility.